export class Role {
    name: string;
}
