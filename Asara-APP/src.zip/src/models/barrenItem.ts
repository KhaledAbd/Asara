export interface BarrenItem {
    itemId:number;
    name:string;
    price:number;
    quentity:number;
    type:number;
    createdAt:Date;
}
