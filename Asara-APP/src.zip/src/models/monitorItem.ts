export interface MonitorItem {
    quentity: number;
    itemName: string;
    employeeName: string;
    type: number;
    createdAt: Date;
    worker: string;
}
