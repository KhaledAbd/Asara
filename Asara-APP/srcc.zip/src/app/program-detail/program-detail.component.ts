import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-program-detail',
  templateUrl: './program-detail.component.html',
  styleUrls: ['./program-detail.component.scss']
})
export class ProgramDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
