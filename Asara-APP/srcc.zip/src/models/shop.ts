export interface Shop {
        id: number;

        name: string;

        address: string;

        telephone: string;

        title: string;
}
